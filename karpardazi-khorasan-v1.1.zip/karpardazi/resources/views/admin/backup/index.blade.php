@extends('layouts.app')

@section('title', 'پشتیبان‌گیری و بازیابی')

@section('content')
    <h5 class="fw-bold mt-3 mb-3">پشتیبان‌گیری و بازیابی پایگاه داده</h5>

    <div class="row g-3">
        <div class="col-md-6">
            <div class="card kpi-card h-100">
                <div class="card-body">
                    <div class="fw-bold mb-2">دریافت نسخه پشتیبان</div>
                    <p class="small text-muted">
                        از کل داده‌های سامانه (پایگاه داده «{{ $database }}») یک فایل SQL تهیه و دانلود می‌شود.
                        این کار را به‌طور منظم (مثلاً هفتگی) انجام دهید.
                    </p>
                    @if($driver === 'mysql')
                        <form method="post" action="{{ route('admin.backup.download') }}">
                            @csrf
                            <button class="btn btn-primary">دانلود نسخه پشتیبان</button>
                        </form>
                    @else
                        <div class="alert alert-warning small mb-0">
                            پشتیبان‌گیری خودکار فقط با MySQL/MariaDB فعال است (پایگاه فعلی: {{ $driver }}).
                        </div>
                    @endif
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card kpi-card h-100">
                <div class="card-body">
                    <div class="fw-bold mb-2">بازیابی از نسخه پشتیبان</div>
                    <div class="alert alert-danger small">
                        توجه: بازیابی، داده‌های فعلی را با محتوای فایل پشتیبان <strong>جایگزین</strong> می‌کند.
                        قبل از بازیابی حتماً یک نسخه پشتیبان جدید دانلود کنید.
                    </div>
                    @if($driver === 'mysql')
                        <form method="post" action="{{ route('admin.backup.restore') }}" enctype="multipart/form-data" onsubmit="return confirm('داده‌های فعلی جایگزین می‌شوند. مطمئن هستید؟')">
                            @csrf
                            <input type="file" name="dump" class="form-control mb-2" accept=".sql" required>
                            <button class="btn btn-danger">بازیابی</button>
                        </form>
                    @endif
                </div>
            </div>
        </div>
    </div>
@endsection
