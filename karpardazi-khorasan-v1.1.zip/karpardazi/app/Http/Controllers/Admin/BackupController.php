<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use Illuminate\Http\Request;
use Symfony\Component\Process\Process;

class BackupController extends Controller
{
    public function index()
    {
        return view('admin.backup.index', [
            'driver' => config('database.default'),
            'database' => config('database.connections.'.config('database.default').'.database'),
        ]);
    }

    public function download()
    {
        if (config('database.default') !== 'mysql') {
            return back()->with('error', 'پشتیبان‌گیری خودکار فقط با پایگاه داده MySQL/MariaDB در دسترس است.');
        }

        $db = config('database.connections.mysql');
        $file = storage_path('app/karpardazi-backup-'.now()->format('Ymd-His').'.sql');

        $process = new Process([
            'mysqldump',
            '--host='.($db['host'] ?? '127.0.0.1'),
            '--port='.($db['port'] ?? '3306'),
            '--user='.$db['username'],
            '--single-transaction',
            '--quick',
            '--no-tablespaces',
            '--result-file='.$file,
            $db['database'],
        ], env: ['MYSQL_PWD' => (string) ($db['password'] ?? '')]);
        $process->setTimeout(300);
        $process->run();

        if (! $process->isSuccessful() || ! is_file($file) || filesize($file) === 0) {
            @unlink($file);

            return back()->with('error', 'پشتیبان‌گیری ناموفق بود. اجرابودن mysqldump روی سرور را بررسی کنید.');
        }

        AuditLog::record('backup_download');

        return response()->download($file, basename($file))->deleteFileAfterSend();
    }

    public function restore(Request $request)
    {
        $request->validate([
            'dump' => ['required', 'file', 'max:102400'],
        ], [
            'required' => 'فایل نسخه پشتیبان را انتخاب کنید.',
            'max' => 'حجم فایل بیش از حد مجاز است.',
        ], ['dump' => 'فایل پشتیبان']);

        if (config('database.default') !== 'mysql') {
            return back()->with('error', 'بازیابی خودکار فقط با پایگاه داده MySQL/MariaDB در دسترس است.');
        }

        $sql = file_get_contents($request->file('dump')->getRealPath());
        if ($sql === false || strlen($sql) < 100 || ! str_contains($sql, 'CREATE')) {
            return back()->with('error', 'فایل انتخاب‌شده یک نسخه پشتیبان معتبر SQL به نظر نمی‌رسد.');
        }

        $db = config('database.connections.mysql');
        $process = new Process([
            'mysql',
            '--host='.($db['host'] ?? '127.0.0.1'),
            '--port='.($db['port'] ?? '3306'),
            '--user='.$db['username'],
            $db['database'],
        ], env: ['MYSQL_PWD' => (string) ($db['password'] ?? '')], input: $sql);
        $process->setTimeout(600);
        $process->run();

        if (! $process->isSuccessful()) {
            return back()->with('error', 'بازیابی ناموفق بود. از سالم‌بودن فایل پشتیبان مطمئن شوید.');
        }

        AuditLog::record('backup_restore');

        return back()->with('success', 'نسخه پشتیبان با موفقیت بازیابی شد.');
    }
}
